Please use [Crowdin](https://crowdin.com/project/xournalpp) to create or edit translations. 
Should a language not be available, you can reach out to the developers by opening a new 
issue or Gitter/Matrix (see links in main README).

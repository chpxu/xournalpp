Eraser and paint / repaint are asynchron.

So here are some classes which are temporary needed to handle this.
This classes are not Model View Control.

#include "XojPdfBookmarkIterator.h"

XojPdfBookmarkIterator::XojPdfBookmarkIterator() = default;

XojPdfBookmarkIterator::~XojPdfBookmarkIterator() = default;

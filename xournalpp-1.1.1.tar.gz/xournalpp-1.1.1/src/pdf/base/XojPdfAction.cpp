#include "XojPdfAction.h"

XojPdfAction::XojPdfAction() = default;

XojPdfAction::~XojPdfAction() = default;

#include "TouchDisableInterface.h"

TouchDisableInterface::TouchDisableInterface() = default;

TouchDisableInterface::~TouchDisableInterface() = default;

void TouchDisableInterface::init() {}

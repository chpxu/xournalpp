#include "ZoomListener.h"

ZoomListener::~ZoomListener() = default;

void ZoomListener::zoomRangeValuesChanged() {}
